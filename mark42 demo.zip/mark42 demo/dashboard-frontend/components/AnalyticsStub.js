export default function AnalyticsStub(){ return (<div><h4>Analytics</h4><p>Events, job runs, sync success/failure charts will appear here.</p></div>) }
