export default function Settings(){ return <div style={{padding:24}}><h1>Settings</h1><p>Theme management and account settings</p></div> }
