FullStack Stats Dashboard — Enhanced Starter (v2)

What's new in v2:
- NextAuth.js integration (Github + Credentials provider skeleton)
- Prisma schema and instructions for Postgres migrations
- Playwright scraper templates for LeetCode/HackerRank/GFG
- Badge engine endpoint and leaderboard endpoint
- Responsive frontend skeleton and analytics stubs
- Queue skeleton (BullMQ) for background sync jobs

Demo UI image path (local): /mnt/data/A_2D_digital_image_of_a_user_interface_titled_"Ful.png

Quick steps to run locally:
1. Start Postgres & Redis (docker-compose recommended)
2. Backend: cd dashboard-backend && npm install && create .env from .env.example (DATABASE_URL, GITHUB_TOKEN, NEXTAUTH_SECRET)
3. Run Prisma migrate: npx prisma migrate dev --name init
4. Start backend: npm run dev
5. Frontend: cd dashboard-frontend && npm install && set NEXT_PUBLIC_API_URL=http://localhost:4000 && npm run dev

Deploying:
- Backend: Render or Cloud Run. Add DATABASE_URL, NEXTAUTH_SECRET, GITHUB_TOKEN env vars.
- Frontend: Vercel. Add NEXT_PUBLIC_API_URL and NEXTAUTH_URL (frontend URL) and NEXTAUTH_SECRET.
